# app/home/views.py

from flask import render_template
from flask_login import login_required
from flask import abort, render_template
from flask_login import current_user, login_required

from . import home

@home.route('/')
def homepage():
    """
    Render the homepage template on the / route
    """
    return render_template('home/index.html', title="Welcome")

@home.route('/dashboard')
@login_required
def dashboard():
    """
    Render the dashboard template on the /dashboard route
    """
    return render_template('home/dashboard.html', title="Dashboard")

# add admin dashboard view
@home.route('/admin/dashboard')
@login_required
def admin_dashboard():
    # prevent non-admins from accessing the page
    if not current_user.role == 'admin':
        abort(403)

    return render_template('home/admin_dashboard.html', title="Dashboard")

#add student dashboard view
@home.route('/student/dashboard')
@login_required
def student_dashboard():
    # prevent non-admins from accessing the page
    #if not (current_user.role == 'student'):
        #abort(403)
    print(current_user.role)
    return render_template('home/student_dashboard.html', title="Dashboard")
@home.route('/parent/dashboard')
def parent_dashboard():
    # prevent non-admins from accessing the page
    #if not (current_user.role == 'student'):
        #abort(403)
    print(current_user.role)
    return render_template('home/parent_dashboard.html', title="Dashboard")