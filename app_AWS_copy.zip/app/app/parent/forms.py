# app/admin/forms.py

from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField
from wtforms.validators import DataRequired
from wtforms.ext.sqlalchemy.fields import QuerySelectField

from ..models import Department, Role, School, Member, Grade, Course, Parent





class StudentAddForm(FlaskForm):
    """
    Form for admin to add or edit a department
    """
    studentid = StringField('Student ID', validators=[DataRequired()])
    #schoolname = StringField('School Name', validators=[DataRequired()])
    submit = SubmitField('Submit')

class SchoolForm(FlaskForm):
    """
    Form for admin to add or edit a school
    """
    schoolname = StringField('School Name', validators=[DataRequired()])
    city = StringField('city', validators=[DataRequired()])
    submit = SubmitField('Submit')

class RoleForm(FlaskForm):
    """
    Form for admin to add or edit a role
    """
    name = StringField('Name', validators=[DataRequired()])
    description = StringField('Description', validators=[DataRequired()])
    submit = SubmitField('Submit')


class EmployeeAssignForm(FlaskForm):
    """
    Form for admin to assign departments and roles to employees
    """
    department = QuerySelectField(query_factory=lambda: Department.query.all(),
                                  get_label="name")
    role = QuerySelectField(query_factory=lambda: Role.query.all(),
                            get_label="name")
    submit = SubmitField('Submit')
